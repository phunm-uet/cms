<a class="btn btn-icon btn-danger deleteDialog tip" data-toggle="modal" data-section="{{ route('users-supers.delete', $item->id) }}" role="button" data-original-title="{{ trans('bases::tables.delete_entry') }}" >
    <i class="fa fa-trash-o"></i>
</a>