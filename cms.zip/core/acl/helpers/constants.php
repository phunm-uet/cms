<?php

if (!defined('AUTH_MODULE_SCREEN_NAME')) {
    define('AUTH_MODULE_SCREEN_NAME', 'auth');
}

if (!defined('USER_MODULE_SCREEN_NAME')) {
    define('USER_MODULE_SCREEN_NAME', 'user');
}

if (!defined('SUPER_USER_MODULE_SCREEN_NAME')) {
    define('SUPER_USER_MODULE_SCREEN_NAME', 'super_user');
}

if (!defined('ROLE_MODULE_SCREEN_NAME')) {
    define('ROLE_MODULE_SCREEN_NAME', 'role');
}

if (!defined('AUTH_ACTION_AFTER_LOGIN_SYSTEM')) {
    define('AUTH_ACTION_AFTER_LOGIN_SYSTEM', 'action_after_login_system');
}

if (!defined('AUTH_ACTION_AFTER_LOGOUT_SYSTEM')) {
    define('AUTH_ACTION_AFTER_LOGOUT_SYSTEM', 'action_after_logout_system');
}

if (!defined('USER_ACTION_AFTER_UPDATE_PROFILE')) {
    define('USER_ACTION_AFTER_UPDATE_PROFILE', 'action_after_update_profile');
}

if (!defined('USER_ACTION_AFTER_UPDATE_PASSWORD')) {
    define('USER_ACTION_AFTER_UPDATE_PASSWORD', 'action_after_update_password');
}