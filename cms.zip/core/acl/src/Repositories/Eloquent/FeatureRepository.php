<?php

namespace Botble\ACL\Repositories\Eloquent;

use Botble\ACL\Repositories\Interfaces\FeatureInterface;
use Botble\Base\Repositories\Eloquent\RepositoriesAbstract;

class FeatureRepository extends RepositoriesAbstract implements FeatureInterface
{

}
