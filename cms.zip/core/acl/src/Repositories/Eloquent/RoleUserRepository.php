<?php

namespace Botble\ACL\Repositories\Eloquent;

use Botble\ACL\Repositories\Interfaces\RoleUserInterface;
use Botble\Base\Repositories\Eloquent\RepositoriesAbstract;

class RoleUserRepository extends RepositoriesAbstract implements RoleUserInterface
{

}
