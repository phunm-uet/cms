<?php

namespace Botble\ACL\Repositories\Eloquent;

use Botble\ACL\Repositories\Interfaces\RoleFlagInterface;
use Botble\Base\Repositories\Eloquent\RepositoriesAbstract;

class RoleFlagRepository extends RepositoriesAbstract implements RoleFlagInterface
{

}
