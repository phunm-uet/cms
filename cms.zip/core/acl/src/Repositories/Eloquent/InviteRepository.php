<?php

namespace Botble\ACL\Repositories\Eloquent;

use Botble\ACL\Repositories\Interfaces\InviteInterface;
use Botble\Base\Repositories\Eloquent\RepositoriesAbstract;

class InviteRepository extends RepositoriesAbstract implements InviteInterface
{

}
