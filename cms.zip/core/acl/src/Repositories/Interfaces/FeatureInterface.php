<?php

namespace Botble\ACL\Repositories\Interfaces;

use Botble\Base\Repositories\Interfaces\RepositoryInterface;

interface FeatureInterface extends RepositoryInterface
{
}
