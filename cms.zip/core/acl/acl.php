<?php

return [
    'avatar' => [
        'container_dir' => 'avatars',
        'default' => '/vendor/core/images/default-avatar.jpg',
    ],
];
